import _ from '@ant-design/icons/es/icons/HighlightOutlined';
export default _;

(self["webpackChunkant_design_pro"] = self["webpackChunkant_design_pro"] || []).push([["mf-dep_src_umi_cache_mfsu_mf-va_C__Users_Yoshi_Desktop_Project_ant-design-pro-master_newVue_node_mod-a8da73"],{

/***/ "./src/.umi/.cache/.mfsu/mf-va_C__Users_Yoshi_Desktop_Project_ant-design-pro-master_newVue_node_modules_@ahooksjs_use-request.js":
/*!***************************************************************************************************************************************!*\
  !*** ./src/.umi/.cache/.mfsu/mf-va_C__Users_Yoshi_Desktop_Project_ant-design-pro-master_newVue_node_modules_@ahooksjs_use-request.js ***!
  \***************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UseAPIProvider": function() { return /* reexport safe */ C_Users_Yoshi_Desktop_Project_ant_design_pro_master_newVue_node_modules_ahooksjs_use_request__WEBPACK_IMPORTED_MODULE_0__.UseAPIProvider; },
/* harmony export */   "UseRequestProvider": function() { return /* reexport safe */ C_Users_Yoshi_Desktop_Project_ant_design_pro_master_newVue_node_modules_ahooksjs_use_request__WEBPACK_IMPORTED_MODULE_0__.UseRequestProvider; },
/* harmony export */   "useAsync": function() { return /* reexport safe */ C_Users_Yoshi_Desktop_Project_ant_design_pro_master_newVue_node_modules_ahooksjs_use_request__WEBPACK_IMPORTED_MODULE_0__.useAsync; },
/* harmony export */   "useLoadMore": function() { return /* reexport safe */ C_Users_Yoshi_Desktop_Project_ant_design_pro_master_newVue_node_modules_ahooksjs_use_request__WEBPACK_IMPORTED_MODULE_0__.useLoadMore; },
/* harmony export */   "usePaginated": function() { return /* reexport safe */ C_Users_Yoshi_Desktop_Project_ant_design_pro_master_newVue_node_modules_ahooksjs_use_request__WEBPACK_IMPORTED_MODULE_0__.usePaginated; }
/* harmony export */ });
/* harmony import */ var C_Users_Yoshi_Desktop_Project_ant_design_pro_master_newVue_node_modules_ahooksjs_use_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@ahooksjs/use-request */ "./node_modules/@ahooksjs/use-request/es/index.js");

/* harmony default export */ __webpack_exports__["default"] = (C_Users_Yoshi_Desktop_Project_ant_design_pro_master_newVue_node_modules_ahooksjs_use_request__WEBPACK_IMPORTED_MODULE_0__.default);



/***/ })

}]);
(self["webpackChunkant_design_pro"] = self["webpackChunkant_design_pro"] || []).push([["mf-dep_src_umi_cache_mfsu_mf-va__ant-design_icons_WarningOutlined_js"],{

/***/ "./node_modules/@ant-design/icons-svg/lib/asn/WarningOutlined.js":
/*!***********************************************************************!*\
  !*** ./node_modules/@ant-design/icons-svg/lib/asn/WarningOutlined.js ***!
  \***********************************************************************/
/***/ (function(__unused_webpack_module, exports) {

"use strict";

// This icon file is generated automatically.
Object.defineProperty(exports, "__esModule", ({ value: true }));
var WarningOutlined = { "icon": { "tag": "svg", "attrs": { "viewBox": "64 64 896 896", "focusable": "false" }, "children": [{ "tag": "path", "attrs": { "d": "M464 720a48 48 0 1096 0 48 48 0 10-96 0zm16-304v184c0 4.4 3.6 8 8 8h48c4.4 0 8-3.6 8-8V416c0-4.4-3.6-8-8-8h-48c-4.4 0-8 3.6-8 8zm475.7 440l-416-720c-6.2-10.7-16.9-16-27.7-16s-21.6 5.3-27.7 16l-416 720C56 877.4 71.4 904 96 904h832c24.6 0 40-26.6 27.7-48zm-783.5-27.9L512 239.9l339.8 588.2H172.2z" } }] }, "name": "warning", "theme": "outlined" };
exports.default = WarningOutlined;


/***/ }),

/***/ "./node_modules/@ant-design/icons/WarningOutlined.js":
/*!***********************************************************!*\
  !*** ./node_modules/@ant-design/icons/WarningOutlined.js ***!
  \***********************************************************/
/***/ (function(module, exports, __webpack_require__) {

"use strict";

  Object.defineProperty(exports, "__esModule", ({
    value: true
  }));
  exports.default = void 0;
  
  var _WarningOutlined = _interopRequireDefault(__webpack_require__(/*! ./lib/icons/WarningOutlined */ "./node_modules/@ant-design/icons/lib/icons/WarningOutlined.js"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _WarningOutlined;
  exports.default = _default;
  module.exports = _default;

/***/ }),

/***/ "./node_modules/@ant-design/icons/lib/icons/WarningOutlined.js":
/*!*********************************************************************!*\
  !*** ./node_modules/@ant-design/icons/lib/icons/WarningOutlined.js ***!
  \*********************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";


var _interopRequireWildcard = __webpack_require__(/*! @babel/runtime/helpers/interopRequireWildcard */ "./node_modules/@babel/runtime/helpers/interopRequireWildcard.js");

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.default = void 0;

var _objectSpread2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/objectSpread2 */ "./node_modules/@babel/runtime/helpers/objectSpread2.js"));

var React = _interopRequireWildcard(__webpack_require__(/*! react */ "./node_modules/react/index.js"));

var _WarningOutlined = _interopRequireDefault(__webpack_require__(/*! @ant-design/icons-svg/lib/asn/WarningOutlined */ "./node_modules/@ant-design/icons-svg/lib/asn/WarningOutlined.js"));

var _AntdIcon = _interopRequireDefault(__webpack_require__(/*! ../components/AntdIcon */ "./node_modules/@ant-design/icons/lib/components/AntdIcon.js"));

// GENERATE BY ./scripts/generate.ts
// DON NOT EDIT IT MANUALLY
var WarningOutlined = function WarningOutlined(props, ref) {
  return /*#__PURE__*/React.createElement(_AntdIcon.default, (0, _objectSpread2.default)((0, _objectSpread2.default)({}, props), {}, {
    ref: ref,
    icon: _WarningOutlined.default
  }));
};

WarningOutlined.displayName = 'WarningOutlined';

var _default = /*#__PURE__*/React.forwardRef(WarningOutlined);

exports.default = _default;

/***/ }),

/***/ "./src/.umi/.cache/.mfsu/mf-va_@ant-design_icons_WarningOutlined.js":
/*!**************************************************************************!*\
  !*** ./src/.umi/.cache/.mfsu/mf-va_@ant-design_icons_WarningOutlined.js ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ant_design_icons_WarningOutlined__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ant-design/icons/WarningOutlined */ "./node_modules/@ant-design/icons/WarningOutlined.js");
/* harmony import */ var _ant_design_icons_WarningOutlined__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons_WarningOutlined__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = ((_ant_design_icons_WarningOutlined__WEBPACK_IMPORTED_MODULE_0___default()));


/***/ })

}]);
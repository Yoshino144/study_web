import _ from '@ant-design/icons/es/icons/TableOutlined';
export default _;

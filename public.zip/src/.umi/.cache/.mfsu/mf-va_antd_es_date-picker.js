import _ from 'C:/Users/Yoshi/Desktop/Project/ant-design-pro-master/newVue/node_modules/antd/es/date-picker';
export default _;

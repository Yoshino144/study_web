import _ from '@ant-design/icons/ProfileOutlined';
export default _;

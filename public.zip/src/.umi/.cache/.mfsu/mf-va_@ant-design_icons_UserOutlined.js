import _ from '@ant-design/icons/UserOutlined';
export default _;

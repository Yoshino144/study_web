import _ from '@ant-design/icons/es/icons/CheckCircleOutlined';
export default _;

(self["webpackChunkant_design_pro"] = self["webpackChunkant_design_pro"] || []).push([["mf-dep_src_umi_cache_mfsu_mf-va_C__Users_Yoshi_Desktop_Project_ant-design-pro-master_newVue_node_mod-50bcdc"],{

/***/ "./src/.umi/.cache/.mfsu/mf-va_C__Users_Yoshi_Desktop_Project_ant-design-pro-master_newVue_node_modules_@umijs_preset-dumi_lib_plugins_features_demo_getDemoRenderArgs.js":
/*!********************************************************************************************************************************************************************************!*\
  !*** ./src/.umi/.cache/.mfsu/mf-va_C__Users_Yoshi_Desktop_Project_ant-design-pro-master_newVue_node_modules_@umijs_preset-dumi_lib_plugins_features_demo_getDemoRenderArgs.js ***!
  \********************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var C_Users_Yoshi_Desktop_Project_ant_design_pro_master_newVue_node_modules_umijs_preset_dumi_lib_plugins_features_demo_getDemoRenderArgs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@umijs/preset-dumi/lib/plugins/features/demo/getDemoRenderArgs */ "./node_modules/@umijs/preset-dumi/lib/plugins/features/demo/getDemoRenderArgs.js");

/* harmony default export */ __webpack_exports__["default"] = (C_Users_Yoshi_Desktop_Project_ant_design_pro_master_newVue_node_modules_umijs_preset_dumi_lib_plugins_features_demo_getDemoRenderArgs__WEBPACK_IMPORTED_MODULE_0__.default);


/***/ })

}]);
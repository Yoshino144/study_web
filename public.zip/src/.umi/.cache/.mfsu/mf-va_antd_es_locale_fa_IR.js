import _ from 'C:/Users/Yoshi/Desktop/Project/ant-design-pro-master/newVue/node_modules/antd/es/locale/fa_IR';
export default _;

import _ from 'C:/Users/Yoshi/Desktop/Project/ant-design-pro-master/newVue/node_modules/antd/es/locale/pt_BR';
export default _;

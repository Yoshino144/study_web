import _ from '@ant-design/icons/WarningOutlined';
export default _;

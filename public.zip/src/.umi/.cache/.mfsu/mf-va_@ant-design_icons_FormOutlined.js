import _ from '@ant-design/icons/FormOutlined';
export default _;

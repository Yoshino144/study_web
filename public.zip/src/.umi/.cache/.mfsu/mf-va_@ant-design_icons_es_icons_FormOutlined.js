import _ from '@ant-design/icons/es/icons/FormOutlined';
export default _;

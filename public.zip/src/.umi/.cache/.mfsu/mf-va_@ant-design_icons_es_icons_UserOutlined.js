import _ from '@ant-design/icons/es/icons/UserOutlined';
export default _;

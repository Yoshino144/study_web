import _ from '@ant-design/charts';
export default _;
export * from '@ant-design/charts';

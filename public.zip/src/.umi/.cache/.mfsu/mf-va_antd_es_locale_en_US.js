import _ from 'C:/Users/Yoshi/Desktop/Project/ant-design-pro-master/newVue/node_modules/antd/es/locale/en_US';
export default _;

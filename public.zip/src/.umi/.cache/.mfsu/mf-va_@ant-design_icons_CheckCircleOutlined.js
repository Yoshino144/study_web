import _ from '@ant-design/icons/CheckCircleOutlined';
export default _;

import _ from '@ant-design/icons/HighlightOutlined';
export default _;

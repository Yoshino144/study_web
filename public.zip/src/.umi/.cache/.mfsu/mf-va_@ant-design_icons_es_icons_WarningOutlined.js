import _ from '@ant-design/icons/es/icons/WarningOutlined';
export default _;

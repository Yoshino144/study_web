import _ from '@ant-design/icons/es/icons/DashboardOutlined';
export default _;

import _ from 'C:/Users/Yoshi/Desktop/Project/ant-design-pro-master/newVue/node_modules/antd/es/button';
export default _;

import _ from '@ant-design/icons/DashboardOutlined';
export default _;
